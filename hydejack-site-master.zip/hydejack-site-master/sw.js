---
---
importScripts("{{ '/assets/js/service-worker.js' | relative_url }}?t={{ site.time | date_to_xmlschema }}");
