---
layout: projects
title: Showcase
show_collection: showcase
description: >
  How people are using Hydejack in the real world. 
  This page is built using the `projects` layout* that is included in the PRO version.
no_groups: true
redirect_from:
  - /projects/
  - /examples/
---

<!-- If you'd like to have your blog or project featured here, please contact me at [mail@hydejack.com](mailto:mail@hydejack.com).  
I'm specifically looking for sites with Hydejack 9 (free or PRO) that show variety and customization.
{:.note title="Call to action"}

<br/> -->