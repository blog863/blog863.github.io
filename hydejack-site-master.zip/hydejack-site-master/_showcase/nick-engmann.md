---
layout: project
title: Nick Engmann
caption: Nick has a ton of cool stuff on his site.
description: >
  Nick has a ton of cool stuff on his site.
  He also happens to use Hydejack, but that's easy to forget when you browse through his incredible content.
image: 
  path: /assets/img/projects/nickengmann.jpg
  srcset:
    1920w: /assets/img/projects/nickengmann.jpg
    960w:  /assets/img/projects/nickengmann@0,5x.jpg
    480w:  /assets/img/projects/nickengmann@0,25x.jpg
date: 16 Jul 2020
links:
  - title: Link
    url: https://nickengmann.com/
accent_image: https://nickengmann.com/assets/img/sidebar-bg.jpg
theme_color: rgb(79,177,186)
redirect_from:
  /showcase/nickengmann/
---

Nick Engmann has a ton of cool stuff on his site.
He also happens to use Hydejack, but that's easy to forget when you browse through his incredible content.
Just promise to come back here after you're done checking out his site, okay?

More about Nick:

> I am Nick Engmann and I hack and design hardware and web dev projects to try & stand out in the crowd and mentor the engineers of tomorrow.
> 
> I created this personal website as a means to keep track of my creations, talk about my experience as an Engineer, and give guidance to anyone looking for someone with my expertise.