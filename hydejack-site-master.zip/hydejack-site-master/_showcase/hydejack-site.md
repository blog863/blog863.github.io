---
layout: project
title: 'Hydejack Site'
caption: Dogfooding Hydejack to sell Hydejack.
description: >
  While Hydejack is built for personal sites, it's versatility allows it to be used a product page as well.
date: '01-01-2016'
image: 
  path: /assets/img/projects/hydejack-site.jpg
  srcset: 
    1920w: /assets/img/projects/hydejack-site.jpg
    960w:  /assets/img/projects/hydejack-site@0,5x.jpg
    480w:  /assets/img/projects/hydejack-site@0,25x.jpg
links:
  - title: Link
    url: https://hydejack.com/
---
