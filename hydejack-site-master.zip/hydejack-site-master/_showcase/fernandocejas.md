---
layout: project
title: Fernando Cejas
caption: An open book
description: >
  "A open book where I express myself and share my ideas, experience and knowledge"
image: 
  path: /assets/img/projects/fernandocejas.jpg
  # srcset:
  #   1920w: /assets/img/projects/austin-huang.jpg
  #   960w:  /assets/img/projects/austin-huang@0,5x.jpg
  #   480w:  /assets/img/projects/austin-huang@0,25x.jpg
date: 23 Dec 2020
links:
  - title: Site
    url: https://www.fernandocejas.com/
accent_image: /assets/img/projects/fernandocejas-bg.jpg
accent_color: rgb(53,141,208)
theme_color: rgb(33,69,97)
---

