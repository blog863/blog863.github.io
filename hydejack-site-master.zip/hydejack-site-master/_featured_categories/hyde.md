---
layout: list
title: Hyde
slug: hyde
description: >
  Hyde is a brazen two-column Jekyll theme that pairs a prominent sidebar with uncomplicated content.
  To see posts about Hydejack, check out the [Hydejack](/blog/hydejack/){:.heading.flip-title} category.
accent_color:    rgb(38,139,210)
theme_color:    rgb(32,32,32)
accent_image:
  background:    rgb(32,32,32)
  overlay:       false
# no_groups: true
---
