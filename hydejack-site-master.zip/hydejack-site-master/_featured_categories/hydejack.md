---
layout: grid
title: Hydejack
slug: hydejack
description: >
  Posts about Hydejack, the two-column [Jekyll](http://jekyllrb.com/) theme based on [Hyde](http://hyde.getpoole.com).
  To see old posts about Hyde, check out the [Hyde](/blog/hyde/){:.heading.flip-title} category instead.
# no_groups: true
---
